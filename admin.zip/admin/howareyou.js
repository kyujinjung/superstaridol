const hello = (name, name1) => {
    console.log(name+'Heelo');
    console.log(name1+'HHeelo');
}


module.exports = hello;