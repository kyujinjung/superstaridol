function hello(name){
  console.log(name + "hello");
}

hello("hong");
